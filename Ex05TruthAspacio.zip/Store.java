package ex05truthaspacio;
import java.util.ArrayList;

public class Store {

    static boolean getName;
  private String name;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList<>();

  public Store(String name){
    this.name = name;
    this.earnings = 0;
    itemList = new ArrayList<>();
    storeList.add(this);
    }
    
  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
    if (index > itemList.size()) {
        System.out.printf("%nSorry, but there are only " + itemList.size() + " items in this store.%n" );
    } 
    else {
        earnings += Item.getItem(index).getCost();
        System.out.printf("%nThe selected item has been sold.%n");
    }
  }
  public void sellItem(String name){
      for (int i = 0; i <= itemList.size(); i++) {
          if (Item.getItem(i).getName().equalsIgnoreCase(name)) {
            earnings += Item.getItem(i).getCost();
            System.out.printf("%nThe selected item has been sold.%n");
            break;
          }
          if (i==itemList.size()) {
            System.out.printf("%nSorry, but this store doesn't sell that item.%n");
          }
      } 
  }
  public void sellItem(Item i){
      if (itemList.contains(i)) {
        earnings += this.Item.getCost();
        System.out.printf("%nThe selected item has been sold.%n");
      }
      else {
        System.out.printf("%nSorry, but this store doesn't sell that item.%n");  
      }
    // check if Item i exists in the store (there is a method that can help with this) (if not, print statement that the store doesn't sell it)
    // get Item i from itemList and add its cost to earnings
    // print statement indicating the sale
  }
  public void addItem(Item i){
    // add Item i to store's itemList
  }
  public void filterType(String type){
    // loop over itemList and print all items with the specified type
  }
  public void filterCheap(double maxCost){
    // loop over itemList and print all items with a cost lower than or equal to the specified value
  }
  public void filterExpensive(double minCost){
    // loop over itemList and print all items with a cost higher than or equal to the specified value
  }
  public static void printStats(){
    // loop over storeList and print the name and the earnings'Store.java'

  }
}
