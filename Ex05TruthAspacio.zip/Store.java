package ex05truthaspacio;
import java.util.ArrayList;

public class Store {

  private String name;
  private double earnings;
  private ArrayList<Item> itemList;
  private static ArrayList<Store> storeList = new ArrayList<>();

  public Store(String name){
    this.name = name;
    this.earnings = 0;
    itemList = new ArrayList<>();
    storeList.add(this);
    }
    
  public String getName(){
    return name;
  }
  public double getEarnings(){
    return earnings;
  }
  public void sellItem(int index){
    if (index > itemList.size()) {
        System.out.printf("%nSorry, but there are only " + itemList.size() + " items in this store.%n" );
    } 
    else {
        earnings += Item.getItem(index).getCost();
        System.out.printf("%nThe selected item has been sold.%n");
    }
  }
  public void sellItem(String name){
      for (int i = 0; i <= itemList.size(); i++) {
          if (Item.getItem(i).getName().equalsIgnoreCase(name)) {
            earnings += Item.getItem(i).getCost();
            System.out.printf("%nThe selected item has been sold.%n");
            break;
          }
          if (i==itemList.size()) {
            System.out.printf("%nSorry, but this store doesn't sell that item.%n");
          }
      } 
  }
  public void sellItem(Item i){
      if (itemList.contains(i)) {
        earnings += i.getCost();
        System.out.printf("%nThe selected item has been sold.%n");
      }
      else {
        System.out.printf("%nSorry, but this store doesn't sell that item.%n");  
      }
  }
  public void addItem(Item i){
      itemList.add(i);
  }
  public void filterType(String type){
      for (int i = 0; i <= itemList.size(); i++) {
          if (type.equalsIgnoreCase(Item.getItem(i).getType())) {
              System.out.printf("Name: %s%nType: %s%nCost:%.2f%n", Item.getItem(i).getName(), Item.getItem(i).getType(), Item.getItem(i).getCost());
          }
      }
  }
  public void filterCheap(double maxCost){
      for (int i = 0; i <= itemList.size(); i++) {
          if ((maxCost<=Item.getItem(i).getCost())) {
              System.out.printf("Name: %s%nType: %s%nCost:%.2f%n", Item.getItem(i).getName(), Item.getItem(i).getType(), Item.getItem(i).getCost());
          }
      }
  }
  public void filterExpensive(double minCost){
      for (int i = 0; i <= itemList.size(); i++) {
          if ((minCost>=Item.getItem(i).getCost())) {
              System.out.printf("Name: %s%nType: %s%nCost:%.2f%n", Item.getItem(i).getName(), Item.getItem(i).getType(), Item.getItem(i).getCost());
          }
      }
  }
  public static void printStats(){
      for (Store s : storeList) {
          System.out.printf("%nName: %s%nEarnings: %.2f%n", s.getName(), s.getEarnings());
      }
    // loop over storeList and print the name and the earnings'Store.java'

  }
}
