/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex03truthaspacio;

/**
 *
 * @author TRUTH
 */
public class Song {
    String title;
    String artist;
    String genre;
    
    public Song(String t, String a, String g){
        title = t;
        artist = a;
        genre = g;
    }
}
