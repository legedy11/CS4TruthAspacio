/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex03truthaspacio;

/**
 *
 * @author TRUTH
 */
public class Singer {
    String name;
    int noOfPerformances;
    double earnings;
    Song favoriteSong;
    
    public Singer(String n, int nOP, double e, Song fS) {
    name = n;
    noOfPerformances = nOP;
    earnings = e;
    favoriteSong = fS;
    }
    
    public void performForAudience(int people) {
        noOfPerformances ++;
        earnings += 100*people;
    }
    public void changeFavSong(Song newSong) {
    favoriteSong = newSong;
    }
}
