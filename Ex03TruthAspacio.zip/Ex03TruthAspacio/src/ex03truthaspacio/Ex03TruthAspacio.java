/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex03truthaspacio;

/**
 *
 * @author TRUTH
 */
public class Ex03TruthAspacio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Unit Sylvain = new Unit("Sylvain Jose Gautier", "Lance", 24);
        Unit Felix = new Unit("Felix Hugo Fraldarius", "Sword", 22);
        Unit Dimitri = new Unit("Dimitri Alexandre Blaiddyd", "Lance", 22);
        
        Song Boyfriend = new Song("Boyfriend", "Big Time Rush", "Pop");
        Song HardwareStore = new Song ("Hardware Store", "'Weird Al' Yankovic", "Parody");
        
        Singer Drake = new Singer("Drake", 7, 500, Boyfriend);
        Drake.performForAudience(12);
        Drake.changeFavSong(HardwareStore);
    }
    
}
